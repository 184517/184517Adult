﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517Adult
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAge_Click(object sender, RoutedEventArgs e)
        {
            int age;
            string output = "";
            int.TryParse(txtAge.Text, out age);
            if (age >= 16)
            {
                lblOutputDrive.Content = "You can get your license";
                output = "You can get your license.";
            }
            else
            {
                lblOutputDrive.Content = "You are too young to get your license";
                output = "You are too young to get your license";
            }
            if (age >= 18)
            {
                lblOutputVote.Content = "You can vote";
                output = output + Environment.NewLine + "You can vote";
            }
            else
            {
                lblOutputVote.Content = "You are too young to vote";
                output = output + Environment.NewLine + "You can't vote";
            }
            if (age >= 19)
            {
                lblOutputDrink.Content = "You can drink";
                output = output + Environment.NewLine + "You can drink";
            }
            else
            {
                lblOutputDrink.Content = "You are too young to drink";
                output = output + Environment.NewLine + "You can't drink";
            }
            lblMcTOutput.Content = output;

        }
    }
}
